import numpy as np
from PIL import Image
import torch
from torch.utils.data import Dataset
import cv2
import os  # 1016
import torchvision  # 240120
import random

# 0329 PIL
class CustomCrop_pos(object):
    def __init__(self, size, position):
        self.size = size
        self.position = position

    def __call__(self, img):
        x, y = self.position
        th, tw = self.size

        # 检查裁剪区域是否超出图像范围
        img_width, img_height = img.size
        if x + tw > img_width or y + th > img_height:
            raise ValueError("裁剪区域超出图像范围")

        return img.crop((x, y, x + tw, y + th))


def APS(image, target1, target2):
    def SA(gray_image):
        target = cv2.Laplacian(gray_image, cv2.CV_64F).var()
        target = (target-50, target+50)
        return target

    # 读取图片
    # image = cv2.imread(r"C:\Users\Zz\Desktop\test_0312\1.jpg")

    # 将图片转换为灰度图
    image = cv2.imread(image)
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    target = SA(gray_image)
    # target = [100, 200]
    # target = [target1, target2]
    closest_smoothness = None
    closest_coords = (None, None)

    for y in range(0, gray_image.shape[0] - 224, 10):
        for x in range(0, gray_image.shape[1] - 224, 10):
            patch = gray_image[y:y + 224, x:x + 224]
            smoothness = cv2.Laplacian(patch, cv2.CV_64F).var()

            if target[0] <= smoothness <= target[1]:
                closest_smoothness = smoothness
                closest_coords = (x, y)
                break  # 直接在目标范围内，结束循环
            elif closest_smoothness is None or abs(smoothness - np.mean(target)) < abs(
                    closest_smoothness - np.mean(target)):
                closest_smoothness = smoothness
                closest_coords = (x, y)

        if closest_smoothness is not None and target[0] <= closest_smoothness <= target[1]:
            break  # 跳出外层循环
    return closest_coords


class MyDataSet(Dataset):  # 修改自MyDataSet_0602(Dataset)
    """
    240412从240120fork 升级了多层级分类网络
    1106 单路rgb
    240401 使用pil的单路ycbcr

    """
    def __init__(self,
                 images_path: list,
                 images_class1: list,
                 images_class2: list,
                 images_class3: list,
                 transform,
                 transform_ycbcr,  # 240120 ycbcr需要先得到 再运行rgb和ycbcr的transform
                 model_id=0,  # 1107新设 为了高效改动代码
                 a=-1, b=-1,  # 0329新设 为了自定义crop
                 target1=0, target2=0  # 240623新设
                 ):
        self.images_path = images_path
        self.images_class1 = images_class1
        self.images_class2 = images_class2
        self.images_class3 = images_class3
        self.transform = transform
        self.transform_ycbcr = transform_ycbcr
        self.model_id = model_id  # 1107
        self.a = a
        self.b = b
        self.target1 = target1
        self.target2 = target2
        # self.mode = mode
        # self.backup_dataset_path = backup_dataset_path


    def __len__(self):
        return len(self.images_path)

    def __getitem__(self, item):
        img_id = os.path.basename(self.images_path[item])
        img_path = self.images_path[item] + "\\" + img_id + ".jpg"
        pth_path = self.images_path[item] + "\\" + "a1030_" + img_id + ".pth"
        """
        逼近一个lap值+双路
        模仿240524.1
        范围target和步长step在函数里设置
        """
        x, y = APS(img_path, self.target1, self.target2)
        crop0329_1 = CustomCrop_pos((224, 224), (x, y))  # 实例化c成为一个f

        img = Image.open(img_path)
        img_rgb = crop0329_1(img)
        img_rgb = self.transform(img_rgb)

        img_ycbcr = img.convert('YCbCr')  # 将RGB图像转换为YCbCr图像
        img_ycbcr = crop0329_1(img_ycbcr)
        img_ycbcr = self.transform_ycbcr(img_ycbcr)  # 240120注意以后若同时用rgb、ycbcr、位置选择创新时检查

        # 0510 此地还无batch
        # 1016 pth部分
        f0123 = torch.load(pth_path)

        # label
        label1 = self.images_class1[item]
        label2 = self.images_class2[item]
        label3 = self.images_class3[item]


        concat_tensor = torch.cat((img_rgb, img_ycbcr), dim=-1)
        data = [concat_tensor, f0123]


        return data, label1, label2, label3  # 这里全读 b123的需求会在model2py里满足

    @staticmethod
    def collate_fn(batch):
        """240412魔改,尝试解决bug"""
        images_and_metadata, label1, label2, label3 = zip(*batch)

        images = []
        metadata = []

        for img_and_metadata in images_and_metadata:
            images.append(img_and_metadata[0])
            metadata.append(img_and_metadata[1])

        images = torch.stack(images, dim=0)
        metadata = torch.stack(metadata, dim=0)

        label1 = torch.as_tensor(label1)
        label2 = torch.as_tensor(label2)
        label3 = torch.as_tensor(label3)

        return [images, metadata], label1, label2, label3
        # 这样，在 collate_fn 中就可以将图片和元数据分开，并分别组成张量。
        # 注意最后的返回值是一个包含了图片和元数据的列表，和标签对应的张量。