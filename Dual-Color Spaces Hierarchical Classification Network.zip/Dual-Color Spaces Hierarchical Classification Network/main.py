import os
import argparse
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.tensorboard import SummaryWriter
import torchvision
import numpy as np
import random
from datetime import datetime
from my_dataset import MyDataSet
from utils import train_one_epoch_hierarchical_classfication, evaluate_hierarchical_classfication, read_split_data_hierarchical_classfication
from timm.models import vision_transformer as offical_vit


class Net_concat(nn.Module):
    def __init__(self, net1):
        super(Net_concat, self).__init__()
        self.net1 = net1

    def forward(self, x):
        x1, x2, x3 = self.net1.forward_features(x)
        x1 = self.net1.forward_head_out1(x1, pre_logits=True)
        x2 = self.net1.forward_head_out2(x2, pre_out1=x1,
                                         pre_logits=True)
        x3 = self.net1.forward_head_out3(x3, pre_out1=x1, pre_out2=x2,
                                         pre_logits=True)
        return x1, x2, x3


class create_Hierarchical_Dual_Color_Spaces_Network(nn.Module):
    def __init__(self, net1, net2, head1, head2, head3):
        super(create_Hierarchical_Dual_Color_Spaces_Network, self).__init__()
        self.net1 = net1
        self.net2 = net2
        self.head1 = head1
        self.head2 = head2
        self.head3 = head3

    def forward(self, x):
        concatenated_tensor, pth = x
        split_tensors = torch.split(concatenated_tensor, 224, dim=-1)
        img_rgb = split_tensors[0]
        img_ycbcr = split_tensors[1]

        x_rgb = [img_rgb, pth]
        x_ycbcr = [img_ycbcr, pth]

        x1_rgb, x2_rgb, x3_rgb = self.net1(x_rgb)
        x1_ycbcr, x2_ycbcr, x3_ycbcr = self.net2(x_ycbcr)

        combined_out1 = torch.cat((x1_rgb, x1_ycbcr), dim=1)  # 0306
        final_output1 = self.head1(combined_out1)

        combined_out2 = torch.cat((final_output1, x2_rgb, x2_ycbcr), dim=1)
        final_output2 = self.head2(combined_out2)

        combined_out3 = torch.cat((final_output1, final_output2, x3_rgb, x3_ycbcr), dim=1)
        final_output3 = self.head3(combined_out3)

        return final_output1, final_output2, final_output3

def create_240518fushion(net1, net2):
    head1 = nn.Linear(768 * 2, 4)
    head2 = nn.Linear(768 * 2 + 4, 4)
    head3 = nn.Linear(768 * 2 + 8, 4)
    fusion_net240518 = create_Hierarchical_Dual_Color_Spaces_Network(net1, net2, head1, head2, head3)
    return fusion_net240518

def Hierarchical_Dual_Color_Spaces_Network_():
    net1 = offical_vit.wjh_vit_base_r50_s16_224_0406H3_V4_se(num_classes=4)
    net2 = offical_vit.wjh_vit_base_r50_s16_224_0406H3_V4_se(num_classes=4)
    net1 = Net_concat(net1)
    net2 = Net_concat(net2)
    return create_240518fushion(net1, net2)


def main(args, net_name, net, seed):
    """
    自定义2个log 1.师兄那样的simple log 2.复制本训练代码
    0402 师兄的log策略  0412 记录abg策略 0416 记录想说的话readme
    """
    logs_savepath = r"logs_train_{}".format(net_name)
    dt01 = datetime.today()  # dt01 各个log的时间
    shixiong_log_path = (r"{}\simplelog_netname{}_time{}_{}_{}_{}.txt"
                         .format(logs_savepath, net_name, dt01.month, dt01.day, dt01.hour, dt01.minute))

    if not os.path.exists(logs_savepath):  # 如果目录不存在，则创建目录
        os.makedirs(logs_savepath)

    # yyc随机种子
    def set_seed(seed):
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

    set_seed(seed)
    # 数据——————————————————————————————————————————————————————————————————————————————————————
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # 有gpu用第一个gpu 没有就用cpu
    print("using {} device.".format(device))
    if torch.cuda.is_available():  # 1023
        net = net.cuda()

    if os.path.exists("./weights") is False:
        os.makedirs("./weights")

    train_images_path, train_images_label1, train_images_label2, train_images_label3, \
    val_images_path, val_images_label1, val_images_label2, val_images_label3, \
    test_images_path, test_images_label1, test_images_label2, test_images_label3 = \
        read_split_data_hierarchical_classfication(dataset_root)

    data_transform = {
        "train": torchvision.transforms.Compose([
            torchvision.transforms.RandomCrop(224),
            torchvision.transforms.ToTensor(),
            torchvision.transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])]),

        "val": torchvision.transforms.Compose([
            torchvision.transforms.RandomCrop(224),
            torchvision.transforms.ToTensor(),
            torchvision.transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])]),

        "train_ycbcr": torchvision.transforms.Compose([
            torchvision.transforms.RandomCrop(224),
            torchvision.transforms.ToTensor(),
            torchvision.transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])]),

        "val_ycbcr": torchvision.transforms.Compose([
            torchvision.transforms.RandomCrop(224),
            torchvision.transforms.ToTensor(),
            torchvision.transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5])])
    }

    # 实例化训练数据集
    train_data_set = MyDataSet(
        images_path=train_images_path,
        images_class1=train_images_label1,
        images_class2=train_images_label2,
        images_class3=train_images_label3,
        transform=data_transform["train"],
        transform_ycbcr=data_transform["train_ycbcr"],
    )

    # 实例化验证数据集
    val_data_set = MyDataSet(
        images_path=val_images_path,
        images_class1=val_images_label1,
        images_class2=val_images_label2,
        images_class3=val_images_label3,
        transform=data_transform["val"],
        transform_ycbcr=data_transform["val_ycbcr"],
    )

    # 240524实例化test数据集
    test_data_set = MyDataSet(
        images_path=test_images_path,
        images_class1=test_images_label1,
        images_class2=test_images_label2,
        images_class3=test_images_label3,
        transform=data_transform["val"],
        transform_ycbcr=data_transform["val_ycbcr"],
    )

    batch_size = args.batch_size
    nw = min([os.cpu_count(), batch_size if batch_size > 1 else 0, 8])  # number of workers
    print('Using {} dataloader workers every process'.format(nw))
    train_dataloader = torch.utils.data.DataLoader(train_data_set,
                                                   batch_size=batch_size,
                                                   shuffle=True,
                                                   pin_memory=True,
                                                   num_workers=nw,
                                                   collate_fn=train_data_set.collate_fn)

    val_dataloader = torch.utils.data.DataLoader(val_data_set,  # 注：240524 把原来的test改为val 因为要落实test了
                                                 batch_size=batch_size,
                                                 shuffle=False,
                                                 pin_memory=True,
                                                 num_workers=nw,
                                                 collate_fn=val_data_set.collate_fn)

    test_dataloader = torch.utils.data.DataLoader(test_data_set,  # 注：240524 把原来的test改为val 因为要落实test了
                                                  batch_size=batch_size,
                                                  shuffle=False,
                                                  pin_memory=True,
                                                  num_workers=nw,
                                                  collate_fn=test_data_set.collate_fn)


    if args.weights != "":
        print("#####注意 加载了预训练权重#####")
        assert os.path.exists(args.weights), "weights file: '{}' not exist.".format(args.weights)
        weights_dict = torch.load(args.weights, map_location=device)
        print(net.load_state_dict(weights_dict['model_state_dict'], strict=False))
        start_epoch = weights_dict['epoch'] + 1  # 从下一个epoch开始
    else:
        start_epoch = 0

    if args.freeze_layers:
        print("#####注意 冻结了层#####")
        for name, para in net.named_parameters():
            # 除head, pre_logits外，其他权重全部冻结
            if "head" not in name and "pre_logits" not in name:
                para.requires_grad_(False)
            else:
                print("training {}".format(name))

    pg = [p for p in net.parameters() if p.requires_grad]
    optimizer = optim.SGD(pg, lr=args.lr, momentum=0.9, weight_decay=5E-5)


    for epoch in range(start_epoch, args.epochs):  # 0413 接着epoch训练
        abg = [0.01 * 5, 0.01 * 10, 0.01 * 85]
        alpha, beta, gamma = abg  # 仅为了记录目的 不然写不进tensorboard

        train_loss, train_acc1, train_acc12, train_acc123, \
        train_num_modified, train_right3wrong2, train_acc2, train_acc3, \
        train_loss1, train_loss2, train_loss3 = \
            train_one_epoch_hierarchical_classfication(model=net,
                                                       optimizer=optimizer,
                                                       data_loader=train_dataloader,
                                                       device=device,
                                                       epoch=epoch,
                                                       bz=batch_size,
                                                       abg=abg  # 0411
                                                       )  # 1023
        # validate
        val_loss, val_acc1, val_acc12, val_acc123, \
        val_num_modified, val_right3wrong2, val_acc2, val_acc3, \
        val_loss1, val_loss2, val_loss3 = \
            evaluate_hierarchical_classfication(model=net,
                                                data_loader=val_dataloader,
                                                device=device,
                                                epoch=epoch,
                                                bz=batch_size,
                                                abg=abg  # 0411
                                                )  # 1023
        print("整体测试集上的正确率: {}".format(val_acc123))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--epochs', type=int, default=600)
    parser.add_argument('--batch-size', type=int, default=16)
    parser.add_argument('--lr', type=float, default=1e-2)  # 1e-2
    parser.add_argument('--lrf', type=float, default=0.01)
    parser.add_argument('--weights', type=str,
                        help='initial weights path')
    parser.add_argument('--freeze-layers', type=bool, default=True)
    opt = parser.parse_args()

    opt.weights=r""
    dataset_root=r""

    main(opt,
         seed=0,
         net_name="Hierarchical_Dual_Color_Spaces_Network",
         net=Hierarchical_Dual_Color_Spaces_Network_(),
         )
