# 来自于噼里啪啦mydataset
import os
import json
import pickle
import random
import torch
import torch.nn as nn
import sys
from tqdm import tqdm
import matplotlib.pyplot as plt

# 画热力图
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import json
import numpy as np

def read_split_data_hierarchical_classfication(root: str, val_rate: float = 0.1, test_rate: float = 0.1):
    """
    0412：
    todo 返回1path（也就是样本）2标签 标签从一个int(0-39)变成a b c
    0408：
    返回1path2标签 标签从一个int(0-39) 变成[a,b,c]
    尝试外科手术式 从flower_class.sort()之后 把单个str改为list【fbfbfb，fb，fb，fb】
    上面0406的方案有训练不动的问题 所以有了本计划
    """

    def class_to_label(_class):
        if _class == 'FB':
            label = 0
        elif _class == 'FL':
            label = 1
        elif _class == 'TW':
            label = 2
        elif _class == 'ori' or _class == 'error':
            label = 3
        else:
            raise Exception("多层级分类类别编码有bug")
        return label

    def modify_value_function(key, value):
        class123 = key.split('-')
        label4 = [None] * 4
        # 0 1 2 3
        # label4[0] = value
        label4[0] = 0
        label4[1] = class_to_label(class123[0])
        label4[2] = class_to_label(class123[1])
        label4[3] = class_to_label(class123[2])

        return label4


    # random.seed(0)  # 保证随机结果可复现  # 1016发现这段没注释掉 影响未知 应该要注释掉  # 240421 主文件里已经用了
    assert os.path.exists(root), "dataset root: {} does not exist.".format(root)

    # 遍历文件夹，一个文件夹对应一个类别
    flower_class = [cla for cla in os.listdir(root) if os.path.isdir(os.path.join(root, cla))]
    # 排序，保证顺序一致
    flower_class.sort()
    # 生成类别名称以及对应的数字索引
    class_indices = dict((k, v) for v, k in enumerate(flower_class))

    # 遍历每个键值对并修改值
    for key, value in class_indices.items():
        """
        class是类别名称
        label是对应数字
        0是总 a-b-c
        123分别是abc
        """
        # 调用修改值的函数，假设为modify_value_function()
        new_value = modify_value_function(key, value)
        # 更新字典中对应键的值
        class_indices[key] = new_value

    # 0410 不兼容 新改json记录
    # json_str = json.dumps(dict((val, key) for key, val in class_indices.items()), indent=4)
    # with open('class_indices.json', 'w') as json_file:
    #     json_file.write(json_str)
    with open('class_indices.json', 'w') as f:
        json.dump(class_indices, f)

    train_images_path = []  # 存储所有图片路径
    train_images_label1 = []  # 存储图片对应索引信息  # 0412
    train_images_label2 = []
    train_images_label3 = []

    val_images_path = []
    val_images_label1 = []
    val_images_label2 = []
    val_images_label3 = []

    test_images_path = []
    test_images_label1 = []
    test_images_label2 = []
    test_images_label3 = []

    # 0602增加pth
    # supported = [".jpg", ".JPG", ".png", ".PNG", ".pth"]  # 支持的文件后缀类型  # 1016注释掉了 因为要的是文件夹
    # 遍历每个文件夹下的文件
    for cla in flower_class:
        cla_path = os.path.join(root, cla)
        # 遍历获取supported支持的所有文件路径
        images = [os.path.join(root, cla, i) for i in os.listdir(cla_path)]
                  # if os.path.splitext(i)[-1] in supported]  # 1016注释掉了 因为要的是文件夹 并在上一行结尾]
        # 获取该类别对应的索引
        image_class = class_indices[cla]

        # 240421 分train val test
        # 计算验证集和测试集的样本数量
        val_size = int(len(images) * val_rate)
        test_size = int(len(images) * test_rate)

        # 从打乱后的列表中随机抽取验证集
        val_images = random.sample(images, val_size)
        # 剩余的部分作为训练和测试集
        remaining_images = [img for img in images if img not in val_images]
        # 从剩余的部分中再随机抽取测试集
        test_images = random.sample(remaining_images, test_size)
        # 剩下的就是训练集
        train_images = [img for img in remaining_images if img not in test_images]

        for img_path in train_images:
            train_images_path.append(img_path)
            train_images_label1.append(image_class[1])
            train_images_label2.append(image_class[2])
            train_images_label3.append(image_class[3])

        for img_path in val_images:
            val_images_path.append(img_path)
            val_images_label1.append(image_class[1])
            val_images_label2.append(image_class[2])
            val_images_label3.append(image_class[3])

        for img_path in test_images:
            test_images_path.append(img_path)
            test_images_label1.append(image_class[1])
            test_images_label2.append(image_class[2])
            test_images_label3.append(image_class[3])

        # for img_path in images:
        #     images_path.append(img_path)
        #     # 0412
        #     images_label1.append(image_class[1])
        #     images_label2.append(image_class[2])
        #     images_label3.append(image_class[3])
    print("read {} train data(folders containing pictures and pth).".format(len(train_images_path)))
    print("read {} val data(folders containing pictures and pth).".format(len(val_images_path)))
    print("read {} test data(folders containing pictures and pth).".format(len(test_images_path)))


    # every_class_num.append(len(images))
    # # 按比例随机采样验证样本
    # val_path = random.sample(images, k=int(len(images) * val_rate))
    #
    # for img_path in images:
    #     if img_path in val_path:  # 如果该路径在采样的验证集样本中则存入验证集
    #         val_images_path.append(img_path)
    #         val_images_label.append(image_class)
    #     else:  # 否则存入训练集
    #         train_images_path.append(img_path)
    #         train_images_label.append(image_class)

    return train_images_path, train_images_label1, train_images_label2, train_images_label3, \
           val_images_path, val_images_label1, val_images_label2, val_images_label3, \
           test_images_path, test_images_label1, test_images_label2, test_images_label3

def train_one_epoch_hierarchical_classfication(model, optimizer, data_loader, device, epoch, bz, abg):
    """
    240406 多个loss 一个样本多个label
    240410 123联合准确率
    240412 多个label分开
    240419 归类纠正 单独2 3准确率
    240429 发现归类纠正两个计数器都有bug 但是不影响其他结果 但是240422的1和2实验这两个计数器废了
        1.num_modified pred2为3的话pred3是否本来就是3
        2.useful 13逻辑颠倒了
    240429 验证了可靠：wjh_test_240429
    240429 发现事实：acc1 * acc2 * acc3 一定大于 acc123 因为acc3可能“虚空正确”（在2错的情况下3正确）
    """
    model.train()
    loss_function = torch.nn.CrossEntropyLoss()
    accu_loss = torch.zeros(1).to(device)  # 累计损失
    # accu_num = torch.zeros(1).to(device)   # 累计预测正确的样本数
    accu1_num = torch.zeros(1).to(device)  # 0410
    accu12_num = torch.zeros(1).to(device)
    accu123_num = torch.zeros(1).to(device)
    accu2_num = torch.zeros(1).to(device)  # 240419
    accu3_num = torch.zeros(1).to(device)

    accu_loss1 = torch.zeros(1).to(device)  # 累计损失
    accu_loss2 = torch.zeros(1).to(device)  # 累计损失
    accu_loss3 = torch.zeros(1).to(device)  # 累计损失

    optimizer.zero_grad()

    sample_num = 0
    num_modified = 0  # 2_3归类纠正所使用
    num_modified_useful = 0
    right3wrong2 = 0

    data_loader = tqdm(data_loader, file=sys.stdout)
    # for step, data in enumerate(data_loader):
    for step, (imgs, target1, target2, target3) in enumerate(data_loader):
        # imgs, target1, target2, target3= data
        # sample_num += imgs.shape[0]  # 1023
        # sample_num += bz  # 1023
        sample_num += len(target1)  # 0412 做这个改动 因为最后一个bz除不尽有误差
        if torch.cuda.is_available():  # 1023
            imgs = [img.cuda() for img in imgs]
            target1 = target1.cuda()
            target2 = target2.cuda()
            target3 = target3.cuda()

        # 240410 ----------------------------------------------
        # pred = model(imgs.to(device))
        # pred = model(imgs)  # 1023
        pred1, pred2, pred3 = model(imgs)
        # pred_classes = torch.max(pred, dim=1)[1]
        pred1_classes = torch.max(pred1, dim=1)[1]
        pred2_classes = torch.max(pred2, dim=1)[1]
        pred3_classes = torch.max(pred3, dim=1)[1]


        """
        240419 单独accu2 accu3准确率计算
        这样可以可以观察到分类头2 3各自的训练过程情况 是否过拟合
        注：这部分要放在归类纠正之前
        240511
        再加一个统计量：3对2不对 right3wrong2 直接用他代替useful的位置
        """
        for i in range(len(target1)):
            ans2 = torch.eq(pred2_classes[i], target2[i]).sum()
            ans3 = torch.eq(pred3_classes[i], target1[i]).sum()
            accu2_num += ans2
            accu3_num += ans3
            if ans3 == 1 and ans2 == 0:
                right3wrong2 += 1

        """
            归类纠正 240419
            解决2_3的问题：如果pred2里面有“3” 把pred3的值变为3
            暂时只需要解决2_3的情况 可等混淆矩阵再解决1_2_3的情况 
            首先那样无法提升acc（怎样纠正都是错的） 当然从逻辑上来说 都是要纠正的
        """
        """
        240429
            发现两个bug num_modified和useful的计算都有错误
            240422_1_2_3_4的实验这部分都有bug（bug原因清晰 对结果没有影响）
        240511
            不用设置num_modified_useful因为看num_modified的图表最多不超过2o
            还是不要把归类纠正移动到单独判断2、3acc之前 因为单独判断2 3acc就是想要看看2、3孤立的表现
        """
        # # 改动之前
        # indices = (pred2_classes == 3).nonzero(as_tuple=True)  # 检查 pred2_classes 中是否有值为 3 的元素的索引
        # pred3_classes[indices] = 3  # 将 pred3_classes 中对应索引位置的值改为 3
        # num_modified += len(indices[0])  # fixme fixme
        # # num_modified_useful += (pred1_classes[indices] == target3[indices]).sum().item()  # 240429发现有问题
        # num_modified_useful += (pred3_classes[indices] == target1[indices]).sum().item()

        # 240501纠正
        indices = (pred2_classes == 3).nonzero(as_tuple=False)  # 检查 pred2_classes 中是否有值为 3 的元素的索引
        for i in indices:  # pred2值为3 如果pred3不为3就纠正并计数
            if pred3_classes[i] != 3:
                num_modified += 1
                pred3_classes[i] = 3


        # done 准确率怎么计算需要思考 计算总的还是分开 思考344的问题
        # 准确率计算部分
        # accu_num += torch.eq(pred_classes, targets.to(device)).sum()
        # 240410 wjh_test_0406_6
        for i in range(len(target1)):
            accu1_num += torch.eq(pred1_classes[i], target3[i]).sum()

        for i in range(len(target1)):
            accu12_num += torch.eq(pred1_classes[i], target3[i]).sum() * \
                         torch.eq(pred2_classes[i], target2[i]).sum()

        for i in range(len(target1)):
            accu123_num += torch.eq(pred1_classes[i], target3[i]).sum() * \
                         torch.eq(pred2_classes[i], target2[i]).sum() * \
                         torch.eq(pred3_classes[i], target1[i]).sum()

        # loss = loss_function(pred, targets.to(device))
        loss1 = loss_function(pred1, target3)  # done 还需要打断点来核查 尤其是344的问题 构
        loss2 = loss_function(pred2, target2)  # done 需要看targets的结构 以及target的【？】 123 321对应问题
        loss3 = loss_function(pred3, target1)

        alpha, beta, gamma = abg  # 0411
        loss = alpha * loss1 + beta * loss2 + gamma * loss3
        loss.backward()
        accu_loss += loss.detach()

        accu_loss1 += loss1.detach()
        accu_loss2 += loss2.detach()
        accu_loss3 += loss3.detach()

        # data_loader.desc = "[train epoch {}] loss: {:.3f}, acc: {:.3f}".format(epoch,
        #                                                                        accu_loss.item() / (step + 1),
        #                                                                        accu_num.item() / sample_num)
        data_loader.desc = "[train epoch {}] loss: {:.3f}, acc1: {:.3f}, acc12: {:.3f}, acc123: {:.3f}"\
                               .format(epoch, accu_loss.item() / (step + 1), accu1_num.item() / sample_num,
                                       accu12_num.item() / sample_num, accu123_num.item() / sample_num)


        if not torch.isfinite(loss):
            print('WARNING: non-finite loss, ending training ', loss)
            sys.exit(1)

        optimizer.step()
        optimizer.zero_grad()

    return accu_loss.item() / sample_num, \
           accu1_num.item() / sample_num, \
           accu12_num.item() / sample_num, \
           accu123_num.item() / sample_num, \
           num_modified, \
           right3wrong2, \
           accu2_num.item() / sample_num, \
           accu3_num.item() / sample_num, \
           accu_loss1.item() / sample_num, \
           accu_loss2.item() / sample_num, \
           accu_loss3.item() / sample_num

@torch.no_grad()
def evaluate_hierarchical_classfication(model, data_loader, device, epoch, bz, abg):
    """
    todo 240412 label分开
    240410 主要按照train_one_epoch_240406修改
    注：众多的更新全部依附于train_one_epoch_240406
    """
    loss_function = torch.nn.CrossEntropyLoss()

    model.eval()

    # accu_num = torch.zeros(1).to(device)   # 累计预测正确的样本数
    # accu_loss = torch.zeros(1).to(device)  # 累计损失

    accu_loss = torch.zeros(1).to(device)  # 累计损失
    # accu_num = torch.zeros(1).to(device)   # 累计预测正确的样本数
    accu1_num = torch.zeros(1).to(device)  # 0410
    accu12_num = torch.zeros(1).to(device)
    accu123_num = torch.zeros(1).to(device)
    accu2_num = torch.zeros(1).to(device)  # 240419
    accu3_num = torch.zeros(1).to(device)

    accu_loss1 = torch.zeros(1).to(device)  # 累计损失
    accu_loss2 = torch.zeros(1).to(device)  # 累计损失
    accu_loss3 = torch.zeros(1).to(device)  # 累计损失

    sample_num = 0
    num_modified = 0
    num_modified_useful = 0
    right3wrong2 = 0

    data_loader = tqdm(data_loader, file=sys.stdout)
    for step, (imgs, target1, target2, target3) in enumerate(data_loader):
        # imgs, target1, target2, target3= data
        # sample_num += imgs.shape[0]  # 1023
        # sample_num += bz  # 1023
        sample_num += len(target1)  # 0412 做这个改动 因为最后一个bz除不尽有误差

        if torch.cuda.is_available():  # 1023
            imgs = [img.cuda() for img in imgs]
            target1 = target1.cuda()
            target2 = target2.cuda()
            target3 = target3.cuda()

        pred1, pred2, pred3 = model(imgs)
        # pred_classes = torch.max(pred, dim=1)[1]
        pred1_classes = torch.max(pred1, dim=1)[1]
        pred2_classes = torch.max(pred2, dim=1)[1]
        pred3_classes = torch.max(pred3, dim=1)[1]
        """
        240419 单独accu2 accu3准确率计算
        这样可以可以观察到分类头2 3各自的训练过程情况 是否过拟合
        注：这部分要放在归类纠正之前
        """
        for i in range(len(target1)):
            ans2 = torch.eq(pred2_classes[i], target2[i]).sum()
            ans3 = torch.eq(pred3_classes[i], target1[i]).sum()
            accu2_num += ans2
            accu3_num += ans3
            if ans3 == 1 and ans2 == 0:
                right3wrong2 += 1


        indices = (pred2_classes == 3).nonzero(as_tuple=False)  # 检查 pred2_classes 中是否有值为 3 的元素的索引
        for i in indices:
            if pred3_classes[i] != 3:
                num_modified += 1
                pred3_classes[i] = 3

        # fixme 准确率怎么计算需要思考 计算总的还是分开 思考344的问题
        # 准确率计算部分
        # accu_num += torch.eq(pred_classes, targets.to(device)).sum()
        # 240410 wjh_test_0406_6
        for i in range(len(target1)):
            accu1_num += torch.eq(pred1_classes[i], target3[i]).sum()

        for i in range(len(target1)):
            accu12_num += torch.eq(pred1_classes[i], target3[i]).sum() * \
                          torch.eq(pred2_classes[i], target2[i]).sum()

        for i in range(len(target1)):
            accu123_num += torch.eq(pred1_classes[i], target3[i]).sum() * \
                           torch.eq(pred2_classes[i], target2[i]).sum() * \
                           torch.eq(pred3_classes[i], target1[i]).sum()

        # loss = loss_function(pred, targets.to(device))
        loss1 = loss_function(pred1, target3)  # fixme 还需要打断点来核查 尤其是344的问题 构
        loss2 = loss_function(pred2, target2)  # fixme 需要看targets的结构 以及target的【？】 123 321对应问题
        loss3 = loss_function(pred3, target1)

        alpha, beta, gamma = abg  # 0411
        loss = alpha * loss1 + beta * loss2 + gamma * loss3
        # loss.backward()
        accu_loss += loss.detach()
        accu_loss1 += loss1.detach()
        accu_loss2 += loss2.detach()
        accu_loss3 += loss3.detach()

        data_loader.desc = "[train epoch {}] loss: {:.3f}, acc1: {:.3f}, acc12: {:.3f}, acc123: {:.3f}" \
            .format(epoch, accu_loss.item() / (step + 1), accu1_num.item() / sample_num,
                    accu12_num.item() / sample_num, accu123_num.item() / sample_num)

    return accu_loss.item() / sample_num, \
           accu1_num.item() / sample_num, \
           accu12_num.item() / sample_num, \
           accu123_num.item() / sample_num, \
           num_modified, \
           right3wrong2, \
           accu2_num.item() / sample_num, \
           accu3_num.item() / sample_num, \
           accu_loss1.item() / sample_num, \
           accu_loss2.item() / sample_num, \
           accu_loss3.item() / sample_num


